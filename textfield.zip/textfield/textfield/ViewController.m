//
//  ViewController.m
//  textfield
//
//  Created by Dinesh Jaganathan on 08/11/16.
//  Copyright © 2016 Greens. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    array1=[[NSArray alloc]initWithObjects:@"red ",@"green ",@"blue ",@"yellow ", nil];
    
    array2=[[NSArray alloc]initWithObjects:[UIColor redColor],[UIColor greenColor],[UIColor blueColor],[UIColor yellowColor], nil];
    dict = [NSDictionary dictionaryWithObjects:array2  forKeys:array1];

    
    // Add a "textFieldDidChange" notification method to the text field control.
    [text addTarget:self
                  action:@selector(textFieldDidChange)
        forControlEvents:UIControlEventEditingChanged];
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



-(void)textFieldDidChange
{
    NSLog(@"text-->%@",text.text);
    

   buton.backgroundColor = [dict valueForKey:text.text];
}
@end
