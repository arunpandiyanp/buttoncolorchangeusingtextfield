//
//  ViewController.h
//  textfield
//
//  Created by Dinesh Jaganathan on 08/11/16.
//  Copyright © 2016 Greens. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

{
    
    IBOutlet UIButton *buton;
    NSArray *array1,*array2;
NSString*string;
    IBOutlet UITextField *text;
    UIColor *color;
    NSDictionary *dict;
    
}
@end

